var searchData=
[
  ['x',['x',['../structSistLinear__t.html#a106437fbdef1dee46d7b1c34509e0da1',1,'SistLinear_t']]]
];

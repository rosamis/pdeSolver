var searchData=
[
  ['liberasistlinear',['liberaSistLinear',['../SistemasLineares_8c.html#ae7acbfa45287b31c524467ab6d3f77e3',1,'liberaSistLinear(SistLinear_t *SL):&#160;SistemasLineares.c'],['../SistemasLineares_8h.html#ae7acbfa45287b31c524467ab6d3f77e3',1,'liberaSistLinear(SistLinear_t *SL):&#160;SistemasLineares.c']]]
];

var searchData=
[
  ['m_5fpi',['M_PI',['../pdeSolver_8c.html#ae71449b1cc6e6250b91f539153a7a0d3',1,'pdeSolver.c']]],
  ['main',['main',['../pdeSolver_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'pdeSolver.c']]],
  ['mediatempo',['mediaTempo',['../structMetrica.html#aac2c1968ef74093c6c92364eedfc120e',1,'Metrica']]],
  ['metrica',['Metrica',['../structMetrica.html',1,'']]]
];

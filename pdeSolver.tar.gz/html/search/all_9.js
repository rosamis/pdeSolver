var searchData=
[
  ['norma',['norma',['../structMetrica.html#a213ed1c24b4afdc96ce9c91f9a6c6301',1,'Metrica']]],
  ['normal2residuo',['normaL2Residuo',['../SistemasLineares_8c.html#a7b3b187094b9ddbf49c4bed5e5f1cda2',1,'normaL2Residuo(SistLinear_t *SL):&#160;SistemasLineares.c'],['../SistemasLineares_8h.html#a7b3b187094b9ddbf49c4bed5e5f1cda2',1,'normaL2Residuo(SistLinear_t *SL):&#160;SistemasLineares.c']]],
  ['nx',['nx',['../structSistLinear__t.html#a0f02ce66276316fd835180cf6a033001',1,'SistLinear_t']]],
  ['ny',['ny',['../structSistLinear__t.html#a84d8f1f84f050ca4dfc93a4ceaef2b9a',1,'SistLinear_t']]]
];

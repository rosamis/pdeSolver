var searchData=
[
  ['metrica',['Metrica',['../structMetrica.html',1,'']]]
];

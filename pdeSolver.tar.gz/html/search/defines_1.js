var searchData=
[
  ['fronteira_5fd',['fronteira_d',['../pdeSolver_8c.html#a7e3a57e09cca56bb83ad777eea13534c',1,'pdeSolver.c']]],
  ['fronteira_5fe',['fronteira_e',['../pdeSolver_8c.html#a2a986c2042eff8936a8879f074d927de',1,'pdeSolver.c']]]
];

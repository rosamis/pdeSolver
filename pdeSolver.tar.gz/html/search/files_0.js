var searchData=
[
  ['pdesolver_2ec',['pdeSolver.c',['../pdeSolver_8c.html',1,'']]],
  ['pdesolver_2eh',['pdeSolver.h',['../pdeSolver_8h.html',1,'']]]
];

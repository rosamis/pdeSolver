var searchData=
[
  ['aloca_5fvetor',['aloca_vetor',['../pdeSolver_8c.html#a43a913e2b033cb594f23afadf00f3f87',1,'aloca_vetor(int nx, int ny):&#160;pdeSolver.c'],['../pdeSolver_8h.html#aef4b26199140c8d62efd8bcb29ce2347',1,'aloca_vetor(int nx, int ny):&#160;pdeSolver.c']]],
  ['alocametrica',['alocaMetrica',['../SistemasLineares_8c.html#a0fa56411c2db5133e91703b6d8ff3b5c',1,'alocaMetrica(unsigned int nx, unsigned int ny, int maxIter):&#160;SistemasLineares.c'],['../SistemasLineares_8h.html#a59e191dba6970fc141a705dba6979d0a',1,'alocaMetrica(unsigned int nx, unsigned int ny, int maxIter):&#160;SistemasLineares.c']]],
  ['alocasistlinear',['alocaSistLinear',['../SistemasLineares_8c.html#ad84846c03b1d7cdb3e86725335a8d57d',1,'alocaSistLinear(unsigned int nx, unsigned int ny):&#160;SistemasLineares.c'],['../SistemasLineares_8h.html#acdbd7298023b1063f141df043ed78f2f',1,'alocaSistLinear(unsigned int nx, unsigned int ny):&#160;SistemasLineares.c']]]
];

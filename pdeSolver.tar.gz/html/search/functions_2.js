var searchData=
[
  ['funcao_5ff',['funcao_f',['../pdeSolver_8c.html#a6baa007ee7bf7e4120e7b5d6b645fbdf',1,'funcao_f(int i, int j, real_t pi_quadrado):&#160;pdeSolver.c'],['../pdeSolver_8h.html#a6baa007ee7bf7e4120e7b5d6b645fbdf',1,'funcao_f(int i, int j, real_t pi_quadrado):&#160;pdeSolver.c']]]
];

var searchData=
[
  ['inicializasistlinear',['inicializaSistLinear',['../SistemasLineares_8c.html#a4c76f8fde8fb7cf7848927226cfdab01',1,'inicializaSistLinear(SistLinear_t *SL, int x, int y):&#160;SistemasLineares.c'],['../SistemasLineares_8h.html#a4c76f8fde8fb7cf7848927226cfdab01',1,'inicializaSistLinear(SistLinear_t *SL, int x, int y):&#160;SistemasLineares.c']]]
];

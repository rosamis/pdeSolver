var searchData=
[
  ['normal2residuo',['normaL2Residuo',['../SistemasLineares_8c.html#a7b3b187094b9ddbf49c4bed5e5f1cda2',1,'normaL2Residuo(SistLinear_t *SL):&#160;SistemasLineares.c'],['../SistemasLineares_8h.html#a7b3b187094b9ddbf49c4bed5e5f1cda2',1,'normaL2Residuo(SistLinear_t *SL):&#160;SistemasLineares.c']]]
];

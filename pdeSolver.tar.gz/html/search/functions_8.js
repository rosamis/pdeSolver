var searchData=
[
  ['quadrado',['quadrado',['../pdeSolver_8c.html#ad88327faf5fd74f059692310c90e5b92',1,'quadrado(real_t p):&#160;pdeSolver.c'],['../pdeSolver_8h.html#ad88327faf5fd74f059692310c90e5b92',1,'quadrado(real_t p):&#160;pdeSolver.c']]]
];

var searchData=
[
  ['saida_5fgnuplot',['saida_gnuplot',['../pdeSolver_8c.html#a564d058f86f6f90aefe804cd92604512',1,'saida_gnuplot(Metrica *P, int flagArq, char *arqOut, SistLinear_t *SL):&#160;pdeSolver.c'],['../pdeSolver_8h.html#a564d058f86f6f90aefe804cd92604512',1,'saida_gnuplot(Metrica *P, int flagArq, char *arqOut, SistLinear_t *SL):&#160;pdeSolver.c']]],
  ['solucao',['solucao',['../pdeSolver_8c.html#a7b2dfad9dc1b2ff50aac0731e38faa40',1,'solucao(real_t hx, real_t hy, real_t *x, real_t *y, int ny, int nx):&#160;pdeSolver.c'],['../pdeSolver_8h.html#a7b2dfad9dc1b2ff50aac0731e38faa40',1,'solucao(real_t hx, real_t hy, real_t *x, real_t *y, int ny, int nx):&#160;pdeSolver.c']]]
];

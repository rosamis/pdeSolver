var searchData=
[
  ['timestamp',['timestamp',['../utils_8c.html#ad1f75d4b6d05731f71dd8fe6ee54bfeb',1,'timestamp(void):&#160;utils.c'],['../utils_8h.html#ad1f75d4b6d05731f71dd8fe6ee54bfeb',1,'timestamp(void):&#160;utils.c']]]
];

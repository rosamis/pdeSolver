var searchData=
[
  ['solução_20discreta_20para_20uma_20equação_20diferencial_20parcial',['Solução Discreta para uma Equação Diferencial Parcial',['../index.html',1,'']]]
];

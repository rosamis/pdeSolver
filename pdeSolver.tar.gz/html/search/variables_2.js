var searchData=
[
  ['iter',['iter',['../structMetrica.html#a3cdc8f8c5ed005c8f6788d9b33831cc1',1,'Metrica']]]
];

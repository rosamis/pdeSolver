var searchData=
[
  ['mediatempo',['mediaTempo',['../structMetrica.html#aac2c1968ef74093c6c92364eedfc120e',1,'Metrica']]]
];

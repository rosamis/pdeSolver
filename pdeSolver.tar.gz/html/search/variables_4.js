var searchData=
[
  ['norma',['norma',['../structMetrica.html#a213ed1c24b4afdc96ce9c91f9a6c6301',1,'Metrica']]],
  ['nx',['nx',['../structSistLinear__t.html#a0f02ce66276316fd835180cf6a033001',1,'SistLinear_t']]],
  ['ny',['ny',['../structSistLinear__t.html#a84d8f1f84f050ca4dfc93a4ceaef2b9a',1,'SistLinear_t']]]
];

#ifndef __UTILS_H__
#define __UTILS_H__

#include <stdlib.h>
#include <sys/time.h>

double timestamp(void);

#endif // __UTILS_H__

